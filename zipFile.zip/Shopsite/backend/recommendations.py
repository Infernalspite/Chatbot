"""
STEP 3 — Recommendations router.

File:   backend/recommendations.py
Mount:  add  app.include_router(recommendations.router)  in main.py

GET /recommendations/{product_id}?limit=4&exclude_ids=2,7

Returns up to `limit` products ranked by:
  1. Cosine similarity of Voyage embeddings   (primary)
  2. Keyword / category fallback              (when embeddings not available)
"""

from __future__ import annotations

import json
from typing import Optional

from fastapi import APIRouter, HTTPException, Query
from database import DB_connection

# Import embedding helpers — path-safe since this file lives in backend/
try:
    from embeddings import (
        cosine_similarity,
        get_embedding,
        load_embedding,
        product_text,
        upsert_product_embedding,
    )
    EMBEDDINGS_ENABLED = True
except ImportError:
    EMBEDDINGS_ENABLED = False   # voyageai not installed yet → fallback only

router = APIRouter(prefix="/recommendations", tags=["recommendations"])


# ── Helper: fetch one product with all fields ─────────────────────────────────
def _fetch_product(product_id: int) -> dict:
    conn = DB_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT id, name, price, stock, image_url,
                       category, sub_category, description, tags
                FROM   products
                WHERE  id = %s
            """, (product_id,))
            row = cur.fetchone()
            if not row:
                raise HTTPException(status_code=404, detail="Product not found")
            return row
    finally:
        conn.close()


# ── Helper: fetch all OTHER products ─────────────────────────────────────────
def _fetch_other_products(exclude_ids: list[int]) -> list[dict]:
    conn = DB_connection()
    try:
        with conn.cursor() as cur:
            placeholders = ",".join(["%s"] * len(exclude_ids))
            cur.execute(f"""
                SELECT id, name, price, stock, image_url,
                       category, sub_category, description, tags
                FROM   products
                WHERE  id NOT IN ({placeholders})
                  AND  stock > 0
            """, tuple(exclude_ids))
            return cur.fetchall()
    finally:
        conn.close()


# ── Strategy 1: Embedding-based cosine similarity ─────────────────────────────
def _recommend_by_embeddings(
    source: dict,
    candidates: list[dict],
    limit: int,
) -> list[dict]:
    """
    Returns candidates sorted by cosine similarity to source embedding.
    If source has no stored embedding, generates one on-the-fly and caches it.
    """
    # Get / generate source embedding
    src_emb = load_embedding(source["id"])
    if src_emb is None:
        src_emb = get_embedding(product_text(source))
        upsert_product_embedding(source["id"], src_emb)

    scored: list[tuple[float, dict]] = []
    for cand in candidates:
        cand_emb = load_embedding(cand["id"])
        if cand_emb is None:
            # Generate lazily — only happens for newly-added products
            cand_emb = get_embedding(product_text(cand))
            upsert_product_embedding(cand["id"], cand_emb)

        score = cosine_similarity(src_emb, cand_emb)
        scored.append((score, cand))

    scored.sort(key=lambda t: t[0], reverse=True)
    return [p for _, p in scored[:limit]]


# ── Strategy 2: Keyword / category fallback ───────────────────────────────────
def _recommend_by_keywords(
    source: dict,
    candidates: list[dict],
    limit: int,
) -> list[dict]:
    """
    Simple heuristic: score candidates by shared category / sub-category / tags.
    Used when voyageai is not installed or embeddings haven't been built.
    """
    src_category = (source.get("category") or "").lower()
    src_sub      = (source.get("sub_category") or "").lower()
    src_tags     = set()
    raw_tags     = source.get("tags")
    if raw_tags:
        if isinstance(raw_tags, str):
            raw_tags = json.loads(raw_tags)
        src_tags = {t.lower() for t in raw_tags}

    # Name token overlap
    src_tokens = set((source.get("name") or "").lower().split())

    scored: list[tuple[float, dict]] = []
    for cand in candidates:
        score = 0.0
        if (cand.get("category") or "").lower() == src_category and src_category:
            score += 3.0
        if (cand.get("sub_category") or "").lower() == src_sub and src_sub:
            score += 2.0
        # Tag overlap
        cand_tags = set()
        raw_cand_tags = cand.get("tags")
        if raw_cand_tags:
            if isinstance(raw_cand_tags, str):
                raw_cand_tags = json.loads(raw_cand_tags)
            cand_tags = {t.lower() for t in raw_cand_tags}
        score += len(src_tags & cand_tags)
        # Name token overlap (minor signal)
        cand_tokens = set((cand.get("name") or "").lower().split())
        score += 0.2 * len(src_tokens & cand_tokens)

        scored.append((score, cand))

    scored.sort(key=lambda t: t[0], reverse=True)
    return [p for _, p in scored[:limit]]


# ── Shared response formatter ─────────────────────────────────────────────────
def _format_product(p: dict) -> dict:
    return {
        "id":          p["id"],
        "name":        p["name"],
        "price":       float(p["price"]),
        "stock":       p["stock"],
        "image_url":   p.get("image_url"),
        "category":    p.get("category"),
        "sub_category":p.get("sub_category"),
    }


# ── Main endpoint ─────────────────────────────────────────────────────────────
@router.get("/{product_id}")
def get_recommendations(
    product_id: int,
    limit: int = Query(default=4, ge=1, le=12),
    exclude_ids: Optional[str] = Query(
        default=None,
        description="Comma-separated product IDs to exclude (e.g. current cart)"
    ),
):
    """
    Returns `limit` product recommendations similar to `product_id`.

    Query params:
    - limit       Number of recommendations (1-12, default 4)
    - exclude_ids Comma-separated IDs to skip (e.g. '3,7,12' for cart items)

    Response:
    {
        "strategy": "embeddings" | "keywords",
        "source_id": 5,
        "recommendations": [ { id, name, price, stock, image_url, ... }, … ]
    }
    """
    # Build exclusion set (always exclude the source itself)
    exclude_set = {product_id}
    if exclude_ids:
        for raw in exclude_ids.split(","):
            raw = raw.strip()
            if raw.isdigit():
                exclude_set.add(int(raw))

    source     = _fetch_product(product_id)
    candidates = _fetch_other_products(list(exclude_set))

    if not candidates:
        return {"strategy": "none", "source_id": product_id, "recommendations": []}

    strategy = "keywords"
    try:
        if EMBEDDINGS_ENABLED:
            results  = _recommend_by_embeddings(source, candidates, limit)
            strategy = "embeddings"
        else:
            results  = _recommend_by_keywords(source, candidates, limit)
    except Exception:
        # Any embedding API failure → graceful fallback
        results  = _recommend_by_keywords(source, candidates, limit)
        strategy = "keywords_fallback"

    return {
        "strategy":       strategy,
        "source_id":      product_id,
        "recommendations": [_format_product(r) for r in results],
    }
