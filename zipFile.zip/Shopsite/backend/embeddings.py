"""
STEP 2 — Embedding utilities.

• Uses Anthropic's voyage-3 model via the voyageai SDK.
• Falls back to keyword/category matching if embeddings are not yet built.
• Run   python embeddings.py   once after migration to pre-build all embeddings.
"""

import json
import math
import os
from typing import Optional

import voyageai           # pip install voyageai
from database import DB_connection

VOYAGE_API_KEY = os.getenv("VOYAGE_API_KEY")   # add to your .env file
EMBED_MODEL    = "voyage-3"
EMBED_DIM      = 1024


# ── Voyage client (singleton) ─────────────────────────────────────────────────
def _client():
    return voyageai.Client(api_key=VOYAGE_API_KEY)


# ── Text fingerprint for a product ───────────────────────────────────────────
def product_text(product: dict) -> str:
    """
    Concatenates all searchable fields into a single string for embedding.
    Gracefully handles missing fields (description, tags, category, etc.).
    """
    parts = [
        product.get("name", ""),
        product.get("category", "") or "",
        product.get("sub_category", "") or "",
        product.get("description", "") or "",
    ]
    tags = product.get("tags")
    if tags:
        if isinstance(tags, str):
            tags = json.loads(tags)
        parts.append(" ".join(tags))
    return " | ".join(p for p in parts if p)


# ── Cosine similarity ─────────────────────────────────────────────────────────
def cosine_similarity(a: list[float], b: list[float]) -> float:
    dot  = sum(x * y for x, y in zip(a, b))
    na   = math.sqrt(sum(x * x for x in a))
    nb   = math.sqrt(sum(x * x for x in b))
    return dot / (na * nb) if na and nb else 0.0


# ── Fetch / generate single embedding ────────────────────────────────────────
def get_embedding(text: str) -> list[float]:
    result = _client().embed([text], model=EMBED_MODEL, input_type="document")
    return result.embeddings[0]


# ── Upsert embedding for one product ─────────────────────────────────────────
def upsert_product_embedding(product_id: int, embedding: list[float]):
    conn = DB_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                INSERT INTO product_embeddings (product_id, embedding)
                VALUES (%s, %s)
                ON DUPLICATE KEY UPDATE
                    embedding  = VALUES(embedding),
                    updated_at = CURRENT_TIMESTAMP
            """, (product_id, json.dumps(embedding)))
        conn.commit()
    finally:
        conn.close()


# ── Load stored embedding for a product ──────────────────────────────────────
def load_embedding(product_id: int) -> Optional[list[float]]:
    conn = DB_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT embedding FROM product_embeddings WHERE product_id = %s",
                (product_id,)
            )
            row = cur.fetchone()
            if row:
                raw = row["embedding"]
                return json.loads(raw) if isinstance(raw, str) else raw
            return None
    finally:
        conn.close()


# ── Pre-build ALL embeddings (run once after migration) ───────────────────────
def build_all_embeddings():
    """
    Call this script directly:   python embeddings.py
    It embeds every product that doesn't yet have a stored embedding.
    """
    conn = DB_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT p.id, p.name, p.category, p.sub_category,
                       p.description, p.tags
                FROM   products p
                LEFT   JOIN product_embeddings pe ON pe.product_id = p.id
                WHERE  pe.product_id IS NULL
            """)
            products = cur.fetchall()
    finally:
        conn.close()

    if not products:
        print("✅  All products already have embeddings.")
        return

    print(f"⏳  Building embeddings for {len(products)} products …")
    texts = [product_text(p) for p in products]

    # Voyage supports batch embedding — send all at once
    result = _client().embed(texts, model=EMBED_MODEL, input_type="document")

    for product, embedding in zip(products, result.embeddings):
        upsert_product_embedding(product["id"], embedding)
        print(f"   ✔  product_id={product['id']}  {product['name']}")

    print("✅  Done.")


if __name__ == "__main__":
    build_all_embeddings()
